package connectiondb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class deleteuser {
       public static void main(String[] args){
    	   String dbURL = "jdbc:mysql:// localhost:3306/"; 
    	      // Database name to access 
    	      String dbName = "community"; 
    	      String dbUsername = "root"; 
    	      String dbPassword = "Gokul@9943704287";
    	      Connection con=null;
    		  try {
    			Class.forName("com.mysql.jdbc.Driver");
    		
    	       con= DriverManager.getConnection(dbURL + dbName, 
    	                                                   dbUsername,  
    	                                                   dbPassword); 
    		  }catch (Exception e) {
    				System.out.println(e);
    			} 
    	   Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.execute("Insert into communitydetails (communityname,communitypasscode) values(\"JAVA\",123)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
       }
}
