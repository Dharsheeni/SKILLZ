package connectiondb;

import java.io.File;
import java.io.IOException;

public class filecreator {
 public File filecreatormethod(int cv) {
	  File myObj = new File("sub"+cv+".txt");
      
        try {
        	if (myObj.createNewFile()) {
			System.out.println("File created: " + myObj.getName()+" "+myObj.getCanonicalPath());}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return myObj;
      }
  }
