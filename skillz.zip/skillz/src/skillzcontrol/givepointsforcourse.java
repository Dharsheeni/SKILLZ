package skillzcontrol;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class givepointsforcourse
 */
@WebServlet("/givepointsforcourse")
public class givepointsforcourse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=Connector.getconnection();
		HttpSession session=request.getSession();
		int p=0;
		int id=(int)session.getAttribute("id");
		String value=request.getParameter("pointsval");
		if(!value.equals("points collected")){
	   	try{
	   	    Statement stmt=con.createStatement();
		 ResultSet r=stmt.executeQuery("select * from users where id='"+id+"'");
	 		while(r.next()){
	 			p=r.getInt("points")+5;
	 		}
	 		stmt.executeUpdate("UPDATE users " +
	 		           "SET points ="+p+"  WHERE id="+id);}
	   	catch(Exception e){
	   		System.out.println(e);
	   	}}
	}

}
