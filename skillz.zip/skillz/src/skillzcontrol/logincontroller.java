package skillzcontrol;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class logincontroller
 */
@WebServlet("/logincontroller")
public class logincontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String user=request.getParameter("user");
		String pass=request.getParameter("pass");
		HttpSession session=request.getSession();  
		session.setAttribute("name", user);
		 boolean status=false;
		Connection con=Connector.getconnection();int id=0;
		  
		try{
			String sql = "Select *"//
		               + " from users  where username = ? and pass=?";
		       PreparedStatement pstm = con.prepareStatement(sql);
		       pstm.setString(1, user);
		       pstm.setString(2, pass);
		       ResultSet rp = pstm.executeQuery();
		       status=rp.next();
		if(status==true){
			id=rp.getInt("id");System.out.println(id);
		}
		else{ 
			Statement stmt=con.createStatement();
			stmt.executeUpdate("INSERT INTO `skillz`.`users` (`username`, `pass`, `points`) VALUES ('"+user+"', '"+pass+"', '150')");
			ResultSet rs=stmt.executeQuery("select * from users where username='"+session.getAttribute("name")+"'");
			while(rs.next()){
			id=rs.getInt("id");
		}
		stmt.execute("CREATE TABLE IF NOT EXISTS `skillz`.`"+session.getAttribute("name")+"` (`tasks_enrolled` INT NULL,`task_status` VARCHAR(45) NULL)");
		}
		session.setAttribute("id", id);
		}
		catch(Exception e){
			System.out.println(e);
		}
		RequestDispatcher rd = request.getRequestDispatcher("/design.jsp");
        rd.forward(request, response);
	
	}
}
