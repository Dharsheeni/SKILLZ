package skillzcontrol;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class LoginDao {

    static public int validate(LoginBean loginBean)  {
        int status = 0;

       Connection connection = Connector.getconnection();
       
try{
        
            PreparedStatement preparedStatement = connection
            .prepareStatement("select * from users where username = ? and pass = ? ");
            preparedStatement.setString(1, loginBean.getUsername());
            preparedStatement.setString(2, loginBean.getPassword());

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
           while(rs.next())
           {
        	   status=rs.getInt("id");
        
                }
          
        } catch (Exception e) {
            
          System.out.println(e);
        }
        return status;
    }
}