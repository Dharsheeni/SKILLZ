package skillzcontrol;

import java.sql.*;


public class Database {
	
	private String dbdriver = "com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver)
	{
		try 
		{
			Class.forName(dbDriver);
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection()
	{
		Connection con = null;
		try 
		{
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","Dharshu1999");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return con;
	}
	
	public void insert(Users usersobj)
	{
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "insert into userdb.user values(?,?,?)";
		try
		{
			PreparedStatement prestmt = con.prepareStatement(sql);
			prestmt.setString(1,usersobj.getUsername());
			prestmt.setString(2,usersobj.getEmail());
			prestmt.setString(3,usersobj.getPassword());
			prestmt.executeUpdate();
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void insertCourse(Course courseobj)
	{
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "insert into courseuploaddb.coursesuploaded values(?,?,?)";
		try
		{
			PreparedStatement prestmt = con.prepareStatement(sql);
			prestmt.setString(1,courseobj.getCoursename());
			prestmt.setString(2,courseobj.getDescriptioncrse());
			prestmt.setString(3,courseobj.getTimelinecrse());
			prestmt.executeUpdate();
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
