package skillzcontrol;

import java.sql.Blob;

public class Attachment {
  private int id;
  private int task_id;
  private String filename;
  private Blob filedata;
  private String filedescription;
  Attachment(int id,int task_id,String fname,Blob fdata,String des){
	  this.id=id;
	  this.task_id=task_id;
	  this.filename=fname;
	  this.filedata=fdata;
	  this.filedescription=des;
  }
public int getId() {
	return id;
}
public int getTask_id() {
	return task_id;
}

public String getFilename() {
	return filename;
}

public Blob getFiledata() {
	return filedata;
}
public String getFiledescription() {
	return filedescription;
}
  
}
