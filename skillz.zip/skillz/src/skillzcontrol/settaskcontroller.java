package skillzcontrol;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class settaskcontroller
 */
@WebServlet("/settaskcontroller")
public class settaskcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter ot = response.getWriter();
		String title=request.getParameter("title");
		String description=request.getParameter("descp");
		String tag=request.getParameter("tag");
		Connection con=Connector.getconnection();int count=0;
		try {
		Statement stmt=con.createStatement();  
		  HttpSession session=request.getSession();  
		ResultSet rs=stmt.executeQuery("select * from users where username='"+session.getAttribute("name")+"'");
		int id=0;
		while(rs.next()){
		count=rs.getInt("points");
		id=rs.getInt("id");
		}
		if(count<100){
		ot.println("not enough points to set task");}
		else{ count=count-100;
			stmt.executeUpdate("UPDATE users SET points ='"+count+"'  WHERE username='"+session.getAttribute("name")+"'");
			stmt.execute("INSERT INTO `skillz`.`tasks` (`task_tag`, `task_description`, `task_title`,`task_contributor`) VALUES ('"+tag+"', '"+description+"', '"+title+"','"+id+"')");
			
			
			
			
			//stmt.execute("INSERT INTO `skillz`.`"+session.getAttribute("name")+"` (`task_setted`, `task_submissions`, `task_status`) VALUES ('"+id+"', '"+sub+"','"+status+"')");
			ot.println("Task setting successfull move to task status to track task activity");
		}
		}
		catch(Exception e){}
		
	}

}
