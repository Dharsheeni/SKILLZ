package skillzcontrol;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

 
public class RegisterDao 
{ 
    public String registerUser(RegisterBean registerBean)
     {  
    	 Connection connection = Connector.getconnection();
         String username = registerBean.getUserName();
         String email = registerBean.getEmail();
         String password = registerBean.getPassword();
         System.out.println(email+" "+password+" "+username);
         try
         {
             
            String query = "insert into users(username,mailid,pass,points) values (?,?,?,?)"; 
           
            PreparedStatement ps = connection.prepareStatement(query);
             ps.setString(1, username);
             ps.setString(2, email);
             ps.setString(3, password);
             ps.setInt(4, 150);
             int i= ps.executeUpdate();
             
             if (i!=0)  
             return "SUCCESS"; 
         }
         catch(SQLException e)
         {
           System.out.println(e);
         }       
         return "Oops.. Something went wrong there..!"; 
     }
}
