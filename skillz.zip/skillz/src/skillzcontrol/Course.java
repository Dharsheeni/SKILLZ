package skillzcontrol;

public class Course {
	private String coursename, descriptioncrse, timelinecrse;

	public Course() {
		super();
	}
	
	

	public Course(String coursename, String descriptioncrse, String timelinecrse) {
		super();
		this.coursename = coursename;
		this.descriptioncrse = descriptioncrse;
		this.timelinecrse = timelinecrse;
	}



	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}

	public String getDescriptioncrse() {
		return descriptioncrse;
	}

	public void setDescriptioncrse(String descriptioncrse) {
		this.descriptioncrse = descriptioncrse;
	}

	public String getTimelinecrse() {
		return timelinecrse;
	}

	public void setTimelinecrse(String timelinecrse) {
		this.timelinecrse = timelinecrse;
	}

}
