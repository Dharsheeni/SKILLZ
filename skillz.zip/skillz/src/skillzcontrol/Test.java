package skillzcontrol;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import skillzcontrol.LoginDao;

/**
 * Servlet implementation class Test
 */
@WebServlet("/Test")
public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private LoginDao loginDao;

    public void init() {
        loginDao = new LoginDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        LoginBean loginBean = new LoginBean();
        loginBean.setUsername(username);
        loginBean.setPassword(password);
        int id =LoginDao.validate(loginBean);
        Connection con=Connector.getconnection();
        try {
            if (id!=0) {
            	 HttpSession session = request.getSession();
            	 session.setAttribute("name",loginBean.getUsername());
            	 session.setAttribute("id",id);
            	 Statement stmt=con.createStatement();
            	 stmt.execute("CREATE TABLE IF NOT EXISTS `skillz`.`"+session.getAttribute("name")+"` (`tasks_enrolled` INT NULL,`task_status` VARCHAR(45) NULL)");
            	RequestDispatcher rd=request.getRequestDispatcher("/design.jsp");
            rd.forward(request, response);
             } 
            else {
               
           	 
            	RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");
            rd.forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}