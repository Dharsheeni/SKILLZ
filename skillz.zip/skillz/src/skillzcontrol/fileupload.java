package skillzcontrol;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@MultipartConfig
public class fileupload extends HttpServlet {
  
   
   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, java.io.IOException {
	response.setContentType("text/html");
	PrintWriter ot=response.getWriter();
	     	Connection con=Connector.getconnection();
	     	try{
	     	Statement stmt=con.createStatement();  
			  HttpSession session=request.getSession(); int count=0; String c="";String m="";String k="";
			ResultSet rs=stmt.executeQuery("select * from tasks where task_id='"+session.getAttribute("task_id")+"'");
			while(rs.next()){
				count=rs.getInt("task_completed")+1;
			}
			stmt.executeUpdate("UPDATE tasks " +
			           "SET task_completed ="+count+"  WHERE task_id="+session.getAttribute("task_id"));
			
			stmt.executeUpdate("UPDATE " +session.getAttribute("name")+
			           "SET task_status = completed  WHERE tasks_enrolled="+session.getAttribute("task_id"));
			
			ot.println("success");
			
	    }catch(Exception e){
	    	 e.printStackTrace();
	     }
	      }
            }
   
