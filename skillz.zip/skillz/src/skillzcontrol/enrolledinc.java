package skillzcontrol;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class enrolledinc
 */
@WebServlet("/enrolledinc")
public class enrolledinc extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter ot = response.getWriter();
		Connection con=Connector.getconnection();int count=0;
		HttpSession session=request.getSession();String c="";
		session.setAttribute("task_id", request.getParameter("task_id"));
		try {
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from tasks where task_id='"+request.getParameter("task_id")+"'");
		
		while(rs.next()){
		count=rs.getInt("task_enrolled")+1;
		}
		stmt.executeUpdate("UPDATE tasks " +
		           "SET task_enrolled ="+count+"  WHERE task_id="+request.getParameter("task_id"));
		stmt.executeUpdate("INSERT INTO `skillz`.`"+session.getAttribute("name")+"` (`tasks_enrolled`, `task_status`) VALUES ('"+request.getParameter("task_id")+"', 'enrolled')");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 /*RequestDispatcher rd = request.getRequestDispatcher("/page1.jsp");
	     rd.forward(request, response);*/
		ot.println("Enrolled successfully");
	}

}
