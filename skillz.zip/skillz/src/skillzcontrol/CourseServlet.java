package skillzcontrol;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class CourseServlet
 */
@WebServlet("/CourseServlet")
public class CourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CourseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String course = request.getParameter("course");
		out.print("<h1>Courses Available</h1>");
		out.print("<table border='1'><tr><th>Course Name</th><th>Course Description</th><th>Course Duration</th><th>Points</th>");
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/courses","root","Dharshu1999");
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from courselist where coursename="+course+"");
			while(rs.next())
			{
				out.print("<tr><td>");
				out.println(rs.getString(1));
				out.print("<\td>");
				out.print("<td>");
				out.println(rs.getString(2));
				out.print("<\td>");
				out.print("<td>");
				out.println(rs.getString(3));
				out.print("<\td>");
				out.print("<td>");
				out.println(rs.getString(4));
				out.print("<\td>");
				out.print("<\tr>");
			}
			
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
		out.print("</table>");
	}

}
