package skillzcontrol;


import java.sql.Connection;
import java.sql.DriverManager;
class Connector {
  static Connection getconnection(){
	  
      String dbURL = "jdbc:mysql:// localhost:3306/"; 
      // Database name to access 
      String dbName = "skillz"; 
      String dbUsername = "root"; 
      String dbPassword = "Gokul@9943704287";
      Connection con=null;
	  try {
		Class.forName("com.mysql.jdbc.Driver");
	
       con= DriverManager.getConnection(dbURL + dbName, 
                                                   dbUsername,  
                                                   dbPassword); 
	  }catch (Exception e) {
			System.out.println(e);
		} 
	  return con;
  }
}
