package skillzcontrol;
import connectiondb.filecreator;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




/**
 * Servlet implementation class DownloadAttachmentServlet
 */
@WebServlet("/DownloadAttachmentServlet")
public class DownloadAttachmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int BUFFER_SIZE = 4096;
	 @Override
	   protected void doPost(HttpServletRequest request, HttpServletResponse response)
	           throws ServletException, IOException {
		 HttpSession session=request.getSession(); 
		 PrintWriter ot=response.getWriter();
	       Connection conn = null;
	       try {
	           // Get Database Connection.
	           // (See more in JDBC Tutorial).
	           conn = Connector.getconnection();
	           String task_id = "";
	           try {
	               task_id =request.getParameter("task_id");
	               //ot.println("successfullydownloaded "+task_id);
	           } catch (Exception e) {
	               System.out.println(e);
	           }
	           String sql = "Select *"//
		               + " from attachment  where task_id = ?";
		       PreparedStatement pstm = conn.prepareStatement(sql);
		       pstm.setString(1, task_id);
		       ResultSet rs = pstm.executeQuery();int cv=1;String path="";
		       while (rs.next()) {
		    	   int id=rs.getInt("id");
		           String fileName = rs.getString("filename");
		           Blob fileData = rs.getBlob("filedata");
		           String description = rs.getString("filedescription");
		           ot.print(fileName+" this is filename");
	           Attachment attachment = new Attachment(id,Integer.parseInt(task_id), fileName, fileData, description);
	           BufferedInputStream is = new BufferedInputStream(fileData.getBinaryStream());
	           filecreator fc=new filecreator();
	           File submission=fc.filecreatormethod(cv);
	           path=submission.getCanonicalPath();
	           FileOutputStream fos = new FileOutputStream(submission.getCanonicalPath()+"\\sub"+cv+".txt");cv++;
	           // you can set the size of the buffer
	           byte[] buffer = new byte[2048];
	           int r = 0;
	           while((r = is.read(buffer))!=-1) {
	              fos.write(buffer, 0, r);
	           }
	         
	           fos.flush();
	           fos.close();
	           is.close();
	                      } 
		       
	           ot.println("successfullydownloaded "+path);
	       } catch (Exception e) {
	           e.printStackTrace();
	       }
	   }
}