package skillzcontrol;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Dataoffileupload {
 void dointodatabase(int task_id,String name,int id ){
	  Connection con=Connector.getconnection();
   	try{
   	    Statement stmt=con.createStatement();
		 int count=0;
		ResultSet rs=stmt.executeQuery("select * from tasks where task_id='"+task_id+"'");
		while(rs.next()){
			count=rs.getInt("task_completed")+1;
		}
		stmt.executeUpdate("UPDATE tasks " +
		           "SET task_completed ="+count+"  WHERE task_id="+task_id);
		 String sql="UPDATE `skillz`.`"+name+"` SET `task_status` = 'completed' WHERE (`tasks_enrolled` = '"+task_id+"')";
        
         int rowAffected = stmt.executeUpdate(sql);int p=0;
         ResultSet r=stmt.executeQuery("select * from users where id='"+id+"'");
 		while(r.next()){
 			p=r.getInt("points")+50;
 		}
 		stmt.executeUpdate("UPDATE users " +
 		           "SET points ="+p+"  WHERE id="+id);
 		 //String sqll="UPDATE `skillz`.`"+name+"` SET `task_status` = 'completed' WHERE (`tasks_enrolled` = '"+task_id+"')";
         
          //int rowAffectedd = stmt.executeUpdate(sql);
         System.out.println(rowAffected);
  }catch(Exception e){
	  System.out.println(e);
  }
}
}
